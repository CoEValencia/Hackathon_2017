package interfaz;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.FlowLayout;
import javax.swing.JTextField;
import java.awt.Dimension;
import javax.swing.JLabel;
import java.awt.Font;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.Component;
import javax.swing.SwingConstants;

public class MainWindow extends JFrame {

	private JPanel contentPane;


	/**
	 * Create the frame.
	 */
	private JTextArea textArea;
	public MainWindow() {
		setResizable(false);
		setPreferredSize(new Dimension(800, 600));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 800, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JLabel lblTitulo = new JLabel("Consola de monitoreo");
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setFont(new Font("Times New Roman", Font.PLAIN, 33));
		contentPane.add(lblTitulo, BorderLayout.NORTH);
		
		textArea = new JTextArea();
		textArea.setBackground(Color.BLACK);
		textArea.setForeground(Color.GREEN);
		textArea.setEditable(false);
		textArea.setLineWrap(true);
		contentPane.add(textArea, BorderLayout.CENTER);
		
		JButton btnLlamar = new JButton("Llamar al contacto");
		contentPane.add(btnLlamar, BorderLayout.SOUTH);
	}
	
	
	public void nuevaEntrada(String cadena) {
		textArea.append("\n\n" + new Date() + " > " + cadena);
	}

}
