package servidor;

import java.awt.EventQueue;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import interfaz.MainWindow;

public class Server {

	
	public static void main(String[] args) {
		ServerSocket servidor;
		try {
			servidor = new ServerSocket(6000);
		} catch (IOException e) {
			System.err.println("Imposible establecer un servidor. �Puerto ocupado?");
			return;
		}
		
		MainWindow frame = new MainWindow();
		frame.setVisible(true);
		
		Socket cliente;
		ServerThread hilo;
		while (true) {
			try {
				cliente = servidor.accept();
				hilo = new ServerThread(cliente, frame);
				hilo.start();
			} catch (IOException e) {
				System.err.println("Imposible aceptar el cliente");
				return;
			}

		}

	}
}
