package servidor;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

import javax.swing.JFrame;

import interfaz.MainWindow;

public class ServerThread extends Thread {
	private Socket cliente;
	private MainWindow frame;
	
	public ServerThread(Socket cliente, MainWindow frame) {
		
		this.cliente = cliente;
		this.frame = frame;
	}
	
	
	private final static String[] PALABRAS = {
		"ayuda", "socorro", "dolor", "caído", "caída", "daño", "ay"
	};
	
	public boolean auxilio(String cadena) {
		cadena = cadena.toLowerCase();
		// SI LA ENTRADA NO ES DEL MICRÓFONO SE MUESTRA SIN COMPROBAR EL AUDIO
		if (!cadena.contains("microfono"))
			return true;
		for (String palabra: PALABRAS)
			if (cadena.contains(palabra))
				return true;
		return false;
		
	}
	
	@Override
	public void run() {
		DataInputStream dis;
		try {
			dis = new DataInputStream(cliente.getInputStream());
		} catch (IOException e) {
			System.err.println("Error al recibir los datos");
			return;
		}
		String cadena;
		while(true) {
			byte[] bytes = new byte[1024];
			int leidos;

			try {
				leidos = dis.read(bytes);
			} catch (IOException e) {
				return;
			}
			if (leidos > 0) {
				cadena = new String(bytes);
				System.out.println(cadena);
				if (auxilio(cadena))
					frame.nuevaEntrada(cadena);
			}
			
			try {
				dis.close();
				cliente.close();
			} catch (IOException e) {
				System.err.println("Error al cerrar la conexión");
				return;
			}
			
		}
	}
	
	
	
}
